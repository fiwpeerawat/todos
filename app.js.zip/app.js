
angular.module('ContactApp' , [])
  .controller('ListContactController', function($scope){
    $scope.newContact = {
        fullname : '',
        nickname : '',
        phone : ''
    };

    $scope.contacts = [
      {fullname : 'Nakarin Jungate' , nickname : 'Flook', phone : '091-xxx-xxxx'},
      {fullname : 'Mallika Muhamad' , nickname : 'Mie', phone : '085-xxx-xxxx'},
      {fullname : 'Thanyaporn Pantub' , nickname : 'Ben', phone : '088-xxx-xxxx'},
      {fullname : 'Tula Khongwiriyakit' , nickname : 'Fiat', phone : '087-xxx-xxxx'}
    ];

    $scope.save = function () {
      var contact = new Contact();
      contact.fullname = $scope.newContact.fullname;
      contact.nickname = $scope.newContact.nickname;
      contact.phone = $scope.newContact.phone;

      $scope.contacts.push(contact);

      $scope.newContact.fullname = '';
      $scope.newContact.nickname = '';
      $scope.newContact.phone = '';
    };

    function Contact() {
      this.fullname = ' ';
      this.nickname = ' ';
      this.phone = ' ';
    }

  });
